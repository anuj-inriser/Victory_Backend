import React from 'react';
import { ScrollView, StyleSheet } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import LearningCard from '../components/LearningCard'; // relative import
import learning_image from "../../assets/learning_image.jpg"

const miniCards = [
    { number: 1, title: "What is a Stock Market?" },
    { number: 2, title: "How Companies Get Listed" },
    { number: 3, title: "How Companies Get Unlisted" },
    { number: 4, title: "How Companies Get Blocklisted" },
    // ...
];

const Learning = () => {
    const navigation = useNavigation();

    return (
        <>

            <ScrollView style={styles.container}>
                <LearningCard
                    title="Market Fundametals"
                    bgImage={learning_image}
                    progress={0.52}
                    headline="Understand how the stock market works, its participants, and why prices move."
                    miniCards={miniCards}
                    onMiniCardPress={card => {
                        navigation.navigate('LearningDetail', { card });
                    }}
                    onArrowPress={() => {
                        navigation.navigate('ChapterScreen');
                    }}
                />
            </ScrollView>
            {/* <ScrollView style={styles.container}>
                <LearningCard
                    title="Investing for Beginners"
                    bgImage={learning_image}
                    progress={0.52}
                    headline="Understand how the stock market works, its participants, and why prices move."
                    miniCards={miniCards}
                    onMiniCardPress={card => {
                        navigation.navigate('LearningDetail', { card });
                    }}
                />
            </ScrollView> */}
        </>
    );
};

const styles = StyleSheet.create({
    container: { backgroundColor: '#FFFFFF', flex: 1 },
});

export default Learning;
