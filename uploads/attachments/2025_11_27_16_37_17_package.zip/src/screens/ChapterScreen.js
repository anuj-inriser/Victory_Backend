import React from 'react';
import {
    View,
    Text,
    StyleSheet,
    ImageBackground,
    ScrollView,
    TouchableOpacity,
    Dimensions,
} from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';

const chapters = [
    {
        number: 1,
        title: 'What is a Stock Market?',
        definition: 'The stock market is a financial marketplace where people buy and sell ownership shares of publicly listed companies, known as stocks or equity shares.',
        purpose: [
            'It helps companies raise capital for business expansion by selling ownership (shares) to the public.',
            'It allows investors to invest their money and earn potential returns through dividends and capital appreciation.'
        ],
        howItWorks: [
            'Companies issue new shares through an IPO (Initial Public Offering) in the primary market.',
            'After being listed, these shares are traded between investors in the secondary market via stock exchanges.'
        ]
    },
    // Add other chapters with corresponding data
    // ...
    {
        number: 2,
        title: 'Market Participants & Instruments',
        definition: 'The stock market is a financial marketplace where people buy and sell ownership shares of publicly listed companies, known as stocks or equity shares.',
        purpose: [
            'It helps companies raise capital for business expansion by selling ownership (shares) to the public.',
            'It allows investors to invest their money and earn potential returns through dividends and capital appreciation.'
        ],
        howItWorks: [
            'Companies issue new shares through an IPO (Initial Public Offering) in the primary market.',
            'After being listed, these shares are traded between investors in the secondary market via stock exchanges.'
        ]
    },
    {
        number: 3,
        title: 'Market Indices Explained',
        definition: 'The stock market is a financial marketplace where people buy and sell ownership shares of publicly listed companies, known as stocks or equity shares.',
        purpose: [
            'It helps companies raise capital for business expansion by selling ownership (shares) to the public.',
            'It allows investors to invest their money and earn potential returns through dividends and capital appreciation.'
        ],
        howItWorks: [
            'Companies issue new shares through an IPO (Initial Public Offering) in the primary market.',
            'After being listed, these shares are traded between investors in the secondary market via stock exchanges.'
        ]
    },
    {
        number: 4,
        title: 'Primary vs Secondary Market',
        definition: 'The stock market is a financial marketplace where people buy and sell ownership shares of publicly listed companies, known as stocks or equity shares.',
        purpose: [
            'It helps companies raise capital for business expansion by selling ownership (shares) to the public.',
            'It allows investors to invest their money and earn potential returns through dividends and capital appreciation.'
        ],
        howItWorks: [
            'Companies issue new shares through an IPO (Initial Public Offering) in the primary market.',
            'After being listed, these shares are traded between investors in the secondary market via stock exchanges.'
        ]
    },
    {
        number: 5,
        title: 'How Trading & Settlement Works',
        definition: 'The stock market is a financial marketplace where people buy and sell ownership shares of publicly listed companies, known as stocks or equity shares.',
        purpose: [
            'It helps companies raise capital for business expansion by selling ownership (shares) to the public.',
            'It allows investors to invest their money and earn potential returns through dividends and capital appreciation.'
        ],
        howItWorks: [
            'Companies issue new shares through an IPO (Initial Public Offering) in the primary market.',
            'After being listed, these shares are traded between investors in the secondary market via stock exchanges.'
        ]
    },
];

const progress = 0.52;


export default function ChapterScreen({ navigation }) {
    return (
        <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
            <Text style={styles.sectionTitle}>Market Fundamentals</Text>
            <View style={styles.topCardWrapper}>
                <ImageBackground
                    // source={bgImage}
                    source={require('../../assets/learning_image.jpg')}
                    style={styles.mainCard}
                    imageStyle={{ borderRadius: 15 }}
                >
                    <View style={styles.progressBarBackground}>
                        <View style={[
                            styles.progressBarFill,
                            { width: `${progress * 100}%` }
                        ]} />
                        <Text style={styles.progressText}>{`${Math.round(progress * 100)}%`}</Text>
                    </View>
                    <View style={styles.overlay}>
                        <Text style={styles.headline}>Understand how the stock market works, its participants, and why prices move.</Text>
                    </View>
                </ImageBackground>
            </View>

            <View style={styles.chapterList}>
                {chapters.map((chapter, idx) => (
                    <TouchableOpacity
                        style={styles.chapterCard}
                        key={idx}
                        activeOpacity={0.85}
                        onPress={() => navigation.navigate('ChapterDetails', { chapter })}
                    >
                        <View style={styles.chapterNumberCircle}>
                            <Text style={styles.chapterNumberText}>{chapter.number}</Text>
                        </View>
                        <Text style={styles.chapterTitle}>{chapter.title}</Text>
                    </TouchableOpacity>

                ))}
            </View>

            <View style={styles.chapterList}>
                <TouchableOpacity
                    style={styles.certificateCard}
                    // key={idx}
                    activeOpacity={0.85}
                // onPress={() => navigation.navigate('ChapterDetails', { chapter })}
                >
                    <View style={styles.certificateNumberCircle}>
                        {/* <Text style={styles.chapterNumberText}>{chapter.number}</Text> */}
                        <MaterialIcons name="lock-outline" size={20} color="#fff" />
                    </View>
                    <Text style={styles.certificateTitle}>Certificate</Text>
                </TouchableOpacity>

            </View>
        </ScrollView>
    );
}

const { width } = Dimensions.get('window');
const cardWidth = width * 0.42;

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
        paddingHorizontal: 12,
        paddingTop: 20,
    },
    sectionTitle: {
        fontSize: 18,
        fontWeight: '700',
        color: '#2D2D2D',
        marginBottom: 12,
        marginLeft: 4,
    },
    topCardWrapper: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: 15,
    },
    topCard: {
        width: '100%',
        minHeight: 110,
        borderRadius: 14,
        overflow: 'hidden',
        justifyContent: 'flex-end',
    },
    mainCard: {
        height: 120,
        borderRadius: 15,
        overflow: 'hidden',
        marginBottom: 12,
        justifyContent: 'flex-end',
    },
    progressRow: {
        position: 'absolute',
        top: 10,
        left: 10,
        right: 10,
        flexDirection: 'row',
        alignItems: 'center',
        zIndex: 2,
    },
    progressBarBackground: {
        position: 'absolute',
        top: 12,
        left: 10,
        right: 10,
        height: 7,
        borderRadius: 5,
        backgroundColor: '#eee',
        flexDirection: 'row',
        alignItems: 'center',
    },
    headline: {
        color: '#fff',
        fontSize: 16,
        fontWeight: '500',
    },
    progressBarFill: {
        backgroundColor: '#31C283',
        height: 7,
        borderRadius: 5,
    },
    progressText: {
        position: 'absolute',
        right: 0.00001,
        // top: -14,
        backgroundColor: '#31C283',
        width: 23,
        height: 23,
        borderRadius: 14,
        color: '#fff',
        fontWeight: '500',
        fontSize: 10,
        textAlign: 'center',
        lineHeight: 22,
        overflow: 'hidden'
    },
    overlay: {
        // backgroundColor: 'rgba(0,0,0,0.3)',
        padding: 13,
        borderBottomLeftRadius: 15,
        borderBottomRightRadius: 15,
    },
    topCardText: {
        color: '#fff',
        fontSize: 15,
        fontWeight: '500',
    },
    chapterList: {
        flexDirection: 'row',
        flexWrap: 'wrap',
        justifyContent: 'flex-start',
        marginTop: 8,
    },
    chapterCard: {
        backgroundColor: '#F2EEF7',
        borderRadius: 13,
        width: cardWidth,
        minHeight: 80,
        marginBottom: 15,
        marginRight: 13,
        flexDirection: 'column',
        alignItems: 'flex-start',
        padding: 15,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 8 },
        shadowOpacity: 0.08,
        shadowRadius: 16,
        elevation: 3,
    },
    chapterNumberCircle: {
        width: 24,
        height: 24,
        borderRadius: 19,
        backgroundColor: '#333066',
        alignItems: 'center',
        justifyContent: 'center',
        marginRight: 13,
    },
    chapterNumberText: {
        color: '#fff',
        fontSize: 12,
        fontWeight: '800',
        textAlign: 'center',
    },
    chapterTitle: {
        color: '#2D2D2D',
        fontWeight: '500',
        fontSize: 13,
        letterSpacing: 0.7,
        flexShrink: 1,
        width: 130,
        height: 36,
    },
    certificateCard: {
        backgroundColor: '#F2EEF7',
        borderRadius: 13,
        width: '100%',
        minHeight: 80,
        marginBottom: 15,
        marginRight: 13,
        flexDirection: 'row',
        alignItems: 'flex-start',
        padding: 15,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 8 },
        shadowOpacity: 0.08,
        shadowRadius: 16,
        elevation: 3,
    },
    certificateNumberCircle: {
        width: 40,
        height: 40,
        borderRadius: 19,
        backgroundColor: '#333066',
        alignItems: 'center',
        justifyContent: 'center',
        marginRight: 13,
    },
    certificateTitle: {
        color: '#2D2D2D',
        fontWeight: '700',
        fontSize: 15,
        letterSpacing: 0.7,
        flexShrink: 1,
        width: 130,
        height: 36,
    }
});
