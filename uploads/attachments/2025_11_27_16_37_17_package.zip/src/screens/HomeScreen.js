import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  SafeAreaView,
} from 'react-native';

export default function HomeScreen({ navigation }) {
  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.content}>
        <Text style={styles.title}>Welcome to 1Trade!</Text>

        <Text style={styles.subtitle}>
          You’re successfully logged in. Start managing your portfolio,
          checking market updates, or tracking your DEMAT account.
        </Text>
        <TouchableOpacity
          style={styles.learningBtn}
          onPress={() => navigation.navigate('Learning')}
        >
          <Text style={styles.tradeText}>Learning</Text>
        </TouchableOpacity>
        {/* 🟢 New Trade Order Button */}
        <TouchableOpacity
          style={styles.tradeBtn}
          onPress={() => navigation.navigate('TradeOrderList')}
        >
          <Text style={styles.tradeText}>Open Trade Order</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.logoutBtn}
          onPress={() => navigation.navigate('Login')}
        >
          <Text style={styles.logoutText}>Logout</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff', justifyContent: 'center' },
  content: { alignItems: 'center', paddingHorizontal: 20 },
  title: {
    fontSize: 26,
    fontWeight: '700',
    color: '#2F0079',
    marginBottom: 10,
  },
  subtitle: {
    fontSize: 16,
    textAlign: 'center',
    color: '#444',
    marginBottom: 30,
    lineHeight: 22,
  },

  // 🟢 Trade Order Button Styles
  tradeBtn: {
    backgroundColor: '#007bff',
    borderRadius: 25,
    paddingVertical: 12,
    paddingHorizontal: 40,
    marginBottom: 15,
  },
  tradeText: {
    color: '#fff',
    fontWeight: '600',
    fontSize: 16,
  },

  logoutBtn: {
    backgroundColor: '#2F0079',
    borderRadius: 25,
    paddingVertical: 12,
    paddingHorizontal: 40,
  },
  logoutText: {
    color: '#fff',
    fontWeight: '600',
    fontSize: 16,
  },
});
