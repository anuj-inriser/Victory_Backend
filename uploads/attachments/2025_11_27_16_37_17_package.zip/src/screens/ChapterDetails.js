import React from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';

export default function ChapterDetails({ route }) {
    // Always expect `chapter` as a param
    const { chapter } = route.params || {};

    // Handle missing/undefined chapter data gracefully
    if (!chapter) {
        return (
            <View style={styles.container}>
                <Text>No chapter data provided.</Text>
            </View>
        );
    }

    return (
        <ScrollView style={styles.container}>
            <Text style={styles.chapterNumber}>Stock Market Basics</Text>
            <Text style={styles.chapterHeaderDesc}>
                The stock market is a platform where people buy and sell ownership in companies.
                These ownership units are called shares or stocks.
            </Text>
            <View style={styles.chapterCard}>
                <View style={styles.cardHeader}>
                    <View style={styles.numCircle}>
                        <Text style={styles.numText}>{chapter.number}</Text>
                    </View>
                    <Text style={styles.cardTitle}>{chapter.title}</Text>
                </View>
            </View>
            <View style={styles.box}>
                <Text style={styles.boxHeading}>Definition:</Text>
                <Text style={styles.boxText}>{chapter.definition || 'N/A'}</Text>
            </View>
            <Text style={styles.sectionHeading}>Purpose:</Text>
            {chapter.purpose && chapter.purpose.length > 0 ? (
                chapter.purpose.map((item, idx) => (
                    <Text style={styles.bullet} key={idx}>{idx + 1}. {item}</Text>
                ))
            ) : (
                <Text style={styles.bullet}>N/A</Text>
            )}
            <Text style={styles.sectionHeading}>How It Works:</Text>
            {chapter.howItWorks && chapter.howItWorks.length > 0 ? (
                chapter.howItWorks.map((item, idx) => (
                    <Text style={styles.bullet} key={idx}>{idx + 1}. {item}</Text>
                ))
            ) : (
                <Text style={styles.bullet}>N/A</Text>
            )}
        </ScrollView>
    );
}

const styles = StyleSheet.create({
    container: {
        backgroundColor: '#fff', flex: 1, padding: 18,
    },
    chapterNumber: {
        fontWeight: '700', color: '#28235B', fontSize: 16,
        marginBottom: 2,
    },
    chapterHeaderDesc: {
        color: '#666',
        fontSize: 12,
        fontWeight: '500',
        marginBottom: 10,
        marginTop: 2,
        lineHeight: 19
    },
    chapterCard: {
        borderRadius: 12,
        backgroundColor: '#E6E0E9',
        marginBottom: 12,
        flexDirection: 'row',
        alignItems: 'center',
        paddingHorizontal: 15,
        paddingVertical: 10,
        width: '100%',
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 8 },
        shadowOpacity: 0.08,
        shadowRadius: 16,
        elevation: 3,

    },
    cardHeader: {
        flexDirection: 'row', alignItems: 'center',
    },
    numCircle: {
        width: 33, height: 33,
        borderRadius: 17,
        backgroundColor: '#333066',
        alignItems: 'center', justifyContent: 'center',
        marginRight: 11,
    },
    numText: {
        color: '#fff', fontWeight: '700', fontSize: 18,
    },
    cardTitle: {
        fontWeight: '700',
        fontSize: 14,
        color: '#28235B'
    },
    box: {
        backgroundColor: '#fff',
        padding: 7, marginBottom: 14, marginTop: 8,
    },
    boxHeading: {
        color: '#111439', fontWeight: '700', fontSize: 12, marginBottom: 2
    },
    boxText: {
        fontSize: 12, color: '#666', lineHeight: 19, fontWeight: '500',
    },
    sectionHeading: {
        color: '#28235B', fontWeight: '700', marginTop: 10, marginBottom: 5,
        fontSize: 13,
    },
    bullet: {
        color: '#666', fontWeight: '500', fontSize: 12, marginBottom: 2, marginLeft: 5, lineHeight: 19
    },
});
