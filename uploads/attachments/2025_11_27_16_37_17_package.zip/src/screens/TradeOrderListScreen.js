import React, { useEffect, useState } from "react";
import { SafeAreaView } from "react-native-safe-area-context";
import TopHeader from "../components/TopHeader";
import TopMenuSlider from "../components/TopMenuSlider";
import TopPagination from "../components/TopPagination";
import WatchlistItemCard from "../components/WatchlistItemCard";
import BottomTabBar from "../components/BottomTabBar";

const API_BASE_URL = "http://192.168.1.6:3002/api";

const stocks = [
  {
    id: "1",
    name: "SBI",
    symbol: "SBIN-EQ",
    logo: require("../../assets/sbin.png"),
  },
  {
    id: "2",
    name: "IDEA",
    symbol: "IDEA-EQ",
    logo: require("../../assets/idea.png"),
  },
];

export default function TradeOrderListScreen({ navigation }) {
  const [ltpData, setLtpData] = useState({});

  // 🔹 Function to fetch LTP for single symbol
  const fetchSingleLtp = async (symbol) => {
    try {
      const res = await fetch(
        `${API_BASE_URL}/buyshare/search?symbol=${symbol}&exchange=NSE`
      );
      const data = await res.json();
      if (data.success && data.ltp) {
        // ✅ Update only that symbol, without touching others
        setLtpData((prev) => ({
          ...prev,
          [symbol]: data.ltp,
        }));
      }
    } catch (err) {
      console.log(`❌ LTP fetch failed for ${symbol}:`, err.message);
    }
  };

  // 🔹 Start independent intervals for each stock
  useEffect(() => {
    const timers = stocks.map((s) => {
      fetchSingleLtp(s.symbol); // initial call
      return setInterval(() => fetchSingleLtp(s.symbol), 5000); // live refresh every 5s
    });

    // 🧹 cleanup all intervals
    return () => timers.forEach((t) => clearInterval(t));
  }, []);

  return (
    <SafeAreaView edges={["top", "bottom"]} style={{ flex: 1, backgroundColor: "#fff" }}>
      <TopHeader />
      <TopMenuSlider />
      <TopPagination />

      <WatchlistItemCard
        data={stocks}
        ltpData={ltpData}
        onPressItem={(item) =>
          navigation.navigate("TradeOrder", {
            symbol: item.symbol,
            ltp: ltpData[item.symbol] ?? 0,
          })
        }
      />
      
    </SafeAreaView>
  );
}
