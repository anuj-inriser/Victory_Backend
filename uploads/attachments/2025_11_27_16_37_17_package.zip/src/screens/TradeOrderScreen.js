import React, { useState, useEffect } from "react";
import { View, StyleSheet, ScrollView, Text } from "react-native";
import { useRoute } from "@react-navigation/native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import SwipeButton from "rn-swipe-button";

import TopOrderHeader from "../components/TopOrderHeader";
import NseBseRadioBox from "../components/NseBseRadioBox";
import OrderTopMenu from "../components/OrderTopMenu";
import OrderInputBox from "../components/OrderInputBox";
import OrderDropdownBox from "../components/OrderDropdownBox";

export default function TradeOrderScreen({ navigation }) {
  const route = useRoute();
  const { symbol: passedSymbol } = route.params || {};

  const [selected, setSelected] = useState("NSE");
  const [nseLtp, setNseLtp] = useState("0.00");
  const [bseLtp, setBseLtp] = useState("0.00");
  const symbol = passedSymbol || "WELENT-EQ";

  const API_BASE_URL = "http://192.168.1.6:3002/api"; // change to your backend

  // 🔄 Fetch LTP from API every 5s
  const fetchLtp = async () => {
    try {
      const res = await fetch(
        `${API_BASE_URL}/buyshare/search?symbol=${symbol}&exchange=NSE`
      );
      const data = await res.json();
      if (data.success && data.ltp) {
        setNseLtp(`₹${parseFloat(data.ltp).toFixed(2)}`);
      } else {
        setNseLtp("₹0.00");
      }
    } catch (err) {
      console.error("❌ NSE LTP fetch error:", err.message);
      setNseLtp("₹0.00");
    }
  };

  useEffect(() => {
    fetchLtp();
    const timer = setInterval(fetchLtp, 5000);
    return () => clearInterval(timer);
  }, [symbol]);

  const menuItems = [
    { id: 1, name: "Intraday" },
    { id: 2, name: "Margin" },
    { id: 3, name: "Delivery" },
  ];

  const handleSwipe = () => {
    alert("✅ Order Placed Successfully!");
  };

  return (
    <SafeAreaView style={styles.container} edges={["top", "bottom"]}>
      {/* 🔝 Header */}
      <TopOrderHeader
        title={symbol}
        onBack={() => navigation.goBack()}
        onSettings={() => console.log("Settings clicked")}
      />

      <ScrollView contentContainerStyle={styles.scrollContent}>
        {/* NSE / BSE Radio */}
        <View style={styles.radioContainer}>
          <NseBseRadioBox
            selected={selected}
            nseLtp={nseLtp}
            bseLtp={bseLtp}
            onSelect={(val) => setSelected(val)}
          />
        </View>

        {/* Order Menu Tabs */}
        <View style={styles.menuContainer}>
          <OrderTopMenu items={menuItems} defaultSelected="Intraday" />
        </View>

        {/* Input Boxes */}
        <View style={styles.inputsWrapper}>
          <OrderInputBox label="Price" value={nseLtp.replace("₹", "")} />
          <OrderInputBox label="Quantity" value="0" />
          <OrderInputBox label="Target" value="0" />
          <OrderInputBox label="Stop Loss" value="0" />
          <OrderDropdownBox
            label="Order Type"
            options={["Market", "Limit", "StopLoss_Limit", "StopLoss_Market"]}
            defaultValue="Market"
            onChange={(val) => console.log("Selected:", val)}
          />
          <OrderDropdownBox
            label="Variety"
            options={["Normal", "StopLoss", "Robo"]}
            defaultValue="Normal"
            onChange={(val) => console.log("Selected:", val)}
          />
        </View>

        {/* ⚠️ Note */}
        <Text style={styles.noteText}>
          <Text style={styles.noteHighlight}>Note:</Text> This security is under
          surveillance measures!
        </Text>
      </ScrollView>

      {/* 🟩 Bottom Summary + Swipe to Buy */}
      <View style={styles.bottomContainer}>
        <View style={styles.summaryContainer}>
          <View style={styles.row}>
            <Text style={styles.label}>Balance available</Text>
            <Text style={styles.value}>₹1,56,467</Text>
          </View>
          <View style={styles.row}>
            <Text style={styles.label}>Order value</Text>
            <Text style={styles.value}>₹25,560</Text>
          </View>
          <View style={styles.row}>
            <Text style={styles.label}>Brokerage</Text>
            <Text style={styles.value}>₹50</Text>
          </View>
          <View style={styles.row}>
            <Text style={styles.label}>Charges</Text>
            <Text style={styles.value}>₹28</Text>
          </View>
          <View style={styles.row}>
            <Text style={styles.label}>Closing balance</Text>
            <Text style={styles.value}>₹1,70,345</Text>
          </View>

          <Ionicons
            name="refresh"
            size={20}
            color="#210f47"
            style={styles.refreshIcon}
            onPress={fetchLtp}
          />
        </View>

        <View style={styles.buyContainer}>
          <SwipeButton
            title="Swipe right to buy >>"
            titleFontSize={13}
            titleColor="#210f47"
            railBackgroundColor="#f5f0fa"
            railFillBackgroundColor="#f5f0fa"
            railBorderColor="#f5f0fa"
            thumbIconBackgroundColor="#4CAF50"
            thumbIconBorderColor="#4CAF50"
            thumbIconComponent={() => (
              <View style={styles.buyThumb}>
                <Text style={styles.buyThumbText}>Buy</Text>
              </View>
            )}
            onSwipeSuccess={handleSwipe}
            containerStyles={{
              borderRadius: 25,
              height: 52,
              width: "100%",
              alignSelf: "center",
            }}
            thumbIconStyles={{ borderRadius: 25 }}
          />
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#fff" },
  scrollContent: { alignItems: "center", paddingBottom: 160 },
  radioContainer: { marginTop: 10 },
  menuContainer: { width: "100%", marginTop: 10 },
  inputsWrapper: { marginTop: 10 },
  noteText: {
    marginTop: 10,
    fontSize: 13,
    color: "#333",
    textAlign: "center",
    paddingHorizontal: 20,
  },
  noteHighlight: { color: "#f5a623", fontWeight: "700" },
  bottomContainer: {
    position: "absolute",
    bottom: 0,
    width: "100%",
    backgroundColor: "#fff",
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: -3 },
    shadowOpacity: 0.1,
    shadowRadius: 6,
    elevation: 10,
    paddingHorizontal: 15,
    paddingTop: 10,
    paddingBottom: 15,
  },
  summaryContainer: {
    flexDirection: "row",
    flexWrap: "wrap",
    marginBottom: 10,
    gap: 10,
  },
  row: { width: "30%", marginBottom: 4 },
  label: { fontSize: 12, color: "#555" },
  value: { fontSize: 13, fontWeight: "600", color: "#000" },
  refreshIcon: { position: "absolute", right: 10, top: "70%" },
  buyContainer: {
    marginTop: 10,
    width: "100%",
    alignItems: "center",
    justifyContent: "center",
  },
  buyThumb: {
    backgroundColor: "#4CAF50",
    width: 60,
    height: 36,
    borderRadius: 18,
    alignItems: "center",
    justifyContent: "center",
    elevation: 2,
  },
  buyThumbText: { color: "#fff", fontSize: 14, fontWeight: "600" },
});
