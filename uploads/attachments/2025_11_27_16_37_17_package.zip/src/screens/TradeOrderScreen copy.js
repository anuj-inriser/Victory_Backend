// import React, { useState, useEffect } from "react";
// import {
//   View,
//   Text,
//   TextInput,
//   TouchableOpacity,
//   ScrollView,
//   StyleSheet,
//   Alert,
// } from "react-native";
// import { Picker } from "@react-native-picker/picker";
// import { useRoute } from "@react-navigation/native";
// import TopOrderHeader from "../components/TopOrderHeader";

// export default function TradeOrderScreen() {
//   // 🟢 get symbol from route params
//   const route = useRoute();
//   const { symbol: passedSymbol } = route.params || {};

//   // 🟢 set initial symbol correctly
//   const [symbol, setSymbol] = useState(passedSymbol || "WELENT-EQ");

//   const [exchange, setExchange] = useState("NSE");
//   const [segmentType, setSegmentType] = useState("INTRADAY");
//   const [price, setPrice] = useState("1");
//   const [quantity, setQuantity] = useState("1");
//   const [target, setTarget] = useState("600.45");
//   const [stoploss, setStoploss] = useState("550.45");
//   const [orderType, setOrderType] = useState("MARKET");
//   const [variety, setVariety] = useState("NORMAL");
//   const [ltp, setLtp] = useState(0);
//   const [funds, setFunds] = useState(156467);
//   const [brokerage, setBrokerage] = useState(50);
//   const [externalCharges, setExternalCharges] = useState(28);
//   const [taxes, setTaxes] = useState(28);
//   const [orderValue, setOrderValue] = useState(0);
//   const [closingBalance, setClosingBalance] = useState(0);

//   const API_BASE_URL = "http://192.168.1.6:3002/api";

//   // 💰 Calculate order summary
//   const updateValues = () => {
//     const orderVal = parseFloat(price) * parseFloat(quantity);
//     const closeBal = funds - (orderVal - brokerage - externalCharges - taxes);
//     setOrderValue(orderVal);
//     setClosingBalance(closeBal);
//   };

//   useEffect(() => {
//     updateValues();
//   }, [price, quantity]);

//   // 🔍 Fetch NSE LTP (BSE fixed 0)
//   const fetchSearch = async () => {
//     try {
//       const res = await fetch(
//         `${API_BASE_URL}/buyshare/search?symbol=${symbol}&exchange=NSE`
//       );
//       const data = await res.json();
//       if (data.success) {
//         setLtp(data.ltp);
//       } else {
//         setLtp(0);
//       }
//     } catch (err) {
//       console.error("❌ Search error:", err.message);
//     }
//   };

//   useEffect(() => {
//     fetchSearch();
//     const timer = setInterval(fetchSearch, 5000);
//     return () => clearInterval(timer);
//   }, [symbol]);

//   // 🟢 Place order
//   const placeOrder = async () => {
//     try {
//       const body = {
//         price,
//         quantity,
//         target,
//         stoploss,
//         exchange,
//         symbol,
//         variety,
//         ordertype: orderType,
//         segmentType,
//         symboltoken: "12345",
//       };
//       const res = await fetch(`${API_BASE_URL}/buyshare/create`, {
//         method: "POST",
//         headers: { "Content-Type": "application/json" },
//         body: JSON.stringify(body),
//       });
//       const data = await res.json();
//       if (data.success || data.status === true) {
//         Alert.alert("✅ Order Placed", "Your order has been submitted successfully.");
//       } else {
//         Alert.alert("❌ Order Failed", data.message || "Unknown error");
//       }
//     } catch (err) {
//       Alert.alert("Error", err.message);
//     }
//   };

//   return (
//     <View>
//       <TopOrderHeader />
//       <ScrollView contentContainerStyle={styles.container}>
//         <View style={styles.card}>
//           <Text style={styles.title}>Trade Order</Text>

//           {/* SYMBOL */}
//           <View style={styles.row}>
//             <TextInput
//               style={styles.symbolInput}
//               value={symbol}
//               onChangeText={setSymbol}
//             />
//             {/* <TouchableOpacity style={styles.searchBtn} onPress={fetchSearch}>
//             <Text style={styles.searchText}>Search</Text>
//           </TouchableOpacity> */}
//           </View>

//           {/* EXCHANGE */}
//           <View style={styles.exchangeGroup}>
//             <TouchableOpacity
//               style={[
//                 styles.exchangeOption,
//                 exchange === "NSE" && styles.exchangeActive,
//               ]}
//               onPress={() => setExchange("NSE")}
//             >
//               <Text
//                 style={{
//                   color: exchange === "NSE" ? "#fff" : "#0078D7",
//                   fontWeight: "600",
//                 }}
//               >
//                 NSE ₹{ltp}
//               </Text>
//             </TouchableOpacity>

//             <TouchableOpacity
//               style={[
//                 styles.exchangeOption,
//                 exchange === "BSE" && styles.exchangeActive,
//               ]}
//               onPress={() => setExchange("BSE")}
//             >
//               <Text
//                 style={{
//                   color: exchange === "BSE" ? "#fff" : "#0078D7",
//                   fontWeight: "600",
//                 }}
//               >
//                 BSE ₹0.00
//               </Text>
//             </TouchableOpacity>
//           </View>

//           {/* SEGMENT */}
//           <View style={styles.segmentGroup}>
//             {["INTRADAY", "DELIVERY", "MARGIN"].map((seg) => (
//               <TouchableOpacity
//                 key={seg}
//                 style={[
//                   styles.segmentBtn,
//                   segmentType === seg ? styles.activeSeg : styles.inactiveSeg,
//                 ]}
//                 onPress={() => setSegmentType(seg)}
//               >
//                 <Text
//                   style={{
//                     color: segmentType === seg ? "#fff" : "#333",
//                     fontWeight: "600",
//                   }}
//                 >
//                   {seg}
//                 </Text>
//               </TouchableOpacity>
//             ))}
//           </View>

//           {/* DROPDOWNS */}
//           <View style={styles.inputRow}>
//             <Text style={styles.label}>Order Type</Text>
//             <Picker
//               selectedValue={orderType}
//               style={styles.picker}
//               onValueChange={(val) => setOrderType(val)}
//             >
//               <Picker.Item label="MARKET" value="MARKET" />
//               <Picker.Item label="LIMIT" value="LIMIT" />
//               <Picker.Item label="STOPLOSS_LIMIT" value="STOPLOSS_LIMIT" />
//               <Picker.Item label="STOPLOSS_MARKET" value="STOPLOSS_MARKET" />
//             </Picker>
//           </View>

//           <View style={styles.inputRow}>
//             <Text style={styles.label}>Variety</Text>
//             <Picker
//               selectedValue={variety}
//               style={styles.picker}
//               onValueChange={(val) => setVariety(val)}
//             >
//               <Picker.Item label="NORMAL" value="NORMAL" />
//               <Picker.Item label="STOPLOSS" value="STOPLOSS" />
//               <Picker.Item label="ROBO" value="ROBO" />
//             </Picker>
//           </View>

//           {/* INPUTS */}
//           <Input label="Price" value={price} onChangeText={setPrice} numeric />
//           <Input label="Quantity" value={quantity} onChangeText={setQuantity} numeric />
//           <Input label="Target" value={target} onChangeText={setTarget} numeric />
//           <Input label="Stop Loss" value={stoploss} onChangeText={setStoploss} numeric />

//           {/* FOOTER */}
//           <View style={styles.footer}>
//             <Text>Amount avail: ₹{funds.toLocaleString("en-IN")}</Text>
//             <Text>Order value: ₹{orderValue.toLocaleString("en-IN")}</Text>
//             <Text>Brokerage: ₹{brokerage.toLocaleString("en-IN")}</Text>
//             <Text>External Charges: ₹{externalCharges.toLocaleString("en-IN")}</Text>
//             <Text>Taxes: ₹{taxes.toLocaleString("en-IN")}</Text>
//             <Text>Closing Balance: ₹{closingBalance.toLocaleString("en-IN")}</Text>
//           </View>

//           {/* BUY BUTTON */}
//           <TouchableOpacity style={styles.buyBtn} onPress={placeOrder}>
//             <Text style={styles.buyText}>BUY</Text>
//           </TouchableOpacity>

//           <Text style={styles.swipeHint}>Swipe right to sell →</Text>
//         </View>
//       </ScrollView>
//     </View>
//   );
// }

// const Input = ({ label, value, onChangeText, editable = true, numeric }) => (
//   <View style={styles.inputRow}>
//     <Text style={styles.label}>{label}</Text>
//     <TextInput
//       style={styles.input}
//       value={value?.toString()}
//       onChangeText={onChangeText}
//       editable={editable}
//       keyboardType={numeric ? "numeric" : "default"}
//     />
//   </View>
// );

// const styles = StyleSheet.create({
//   container: { flexGrow: 1, backgroundColor: "#f3f1f6", paddingVertical: 10 },
//   card: {
//     backgroundColor: "#fff",
//     borderRadius: 16,
//     padding: 20,
//     maxWidth: 400,
//     alignSelf: "center",
//     shadowColor: "#000",
//     shadowOpacity: 0.1,
//     shadowRadius: 6,
//   },
//   title: { textAlign: "center", fontSize: 18, fontWeight: "600", marginBottom: 10 },
//   row: { flexDirection: "row", justifyContent: "center", marginBottom: 15 },
//   symbolInput: {
//     borderColor: "#ccc",
//     borderWidth: 1,
//     borderRadius: 8,
//     paddingHorizontal: 10,
//     width: 160,
//     textAlign: "center",
//     fontSize: 16,
//     fontWeight: "600",
//   },
//   searchBtn: {
//     backgroundColor: "#f0a500",
//     marginLeft: 10,
//     paddingHorizontal: 15,
//     borderRadius: 8,
//     justifyContent: "center",
//   },
//   searchText: { color: "#fff", fontWeight: "600" },
//   exchangeGroup: { flexDirection: "row", justifyContent: "center", marginBottom: 10 },
//   exchangeOption: {
//     borderWidth: 1,
//     borderColor: "#0078D7",
//     borderRadius: 25,
//     paddingVertical: 6,
//     paddingHorizontal: 18,
//     marginHorizontal: 5,
//   },
//   exchangeActive: { backgroundColor: "#0078D7" },
//   segmentGroup: { flexDirection: "row", justifyContent: "center", marginVertical: 10 },
//   segmentBtn: {
//     paddingVertical: 8,
//     paddingHorizontal: 16,
//     borderRadius: 20,
//     marginHorizontal: 5,
//     borderWidth: 1,
//     borderColor: "#ccc",
//   },
//   activeSeg: { backgroundColor: "#007bff", borderColor: "#007bff" },
//   inactiveSeg: { backgroundColor: "#f8f9fa" },
//   inputRow: {
//     flexDirection: "row",
//     justifyContent: "space-between",
//     backgroundColor: "#f3f1f6",
//     borderRadius: 10,
//     padding: 10,
//     marginTop: 10,
//     alignItems: "center",
//   },
//   label: { fontWeight: "500", flex: 1 },
//   input: { textAlign: "right", width: "50%", fontWeight: "500" },
//   picker: {
//     height: 60,
//     width: 150,
//     backgroundColor: "#f3f1f6",
//   },
//   footer: { marginTop: 15 },
//   buyBtn: {
//     backgroundColor: "#e53935",
//     padding: 12,
//     borderRadius: 25,
//     marginTop: 15,
//     alignItems: "center",
//   },
//   buyText: { color: "#fff", fontWeight: "600" },
//   swipeHint: { textAlign: "center", color: "#555", marginTop: 5, fontSize: 13 },
// });
