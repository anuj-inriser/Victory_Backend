import React from 'react';
import {
  View,
  Text,
  Image,
  TouchableOpacity,
  StyleSheet,
  SafeAreaView,
  ScrollView,
} from 'react-native';

export default function DematScreen({ navigation }) {
  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={styles.scroll}>
        {/* Illustration */}
        <Image
          source={require('../../assets/demat.png')}
          style={styles.image}
          resizeMode="contain"
        />

        <Text style={styles.title}>Connect Your DEMAT</Text>

        {/* Progress Dots */}
        <View style={styles.dotsContainer}>
          {[...Array(4)].map((_, i) => (
            <View key={i} style={styles.dot} />
          ))}
        </View>

        {/* Buttons */}
        <View style={styles.buttonRow}>
          <TouchableOpacity
            style={styles.skipBtn}
            onPress={() => navigation.navigate('Welcome')}
          >
            <Text style={styles.skipText}>Skip</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.nextBtn}
            onPress={() => alert('Proceed to connect or continue signup')}
          >
            <Text style={styles.nextText}>I don’t have a DEMAT</Text>
          </TouchableOpacity>
        </View>

        {/* Disclaimer */}
        <Text style={styles.disclaimer}>
          Disclaimer: You can securely connect your existing DEMAT accounts, if
          you wish to take trades and access your portfolio,{' '}
          <Text style={{ fontWeight: '700' }}>
            we do not charge you for trades
          </Text>{' '}
          taken through the application, trades happen through your broker only.
        </Text>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff' },
  scroll: { padding: 24, alignItems: 'center' },
  image: { width: '100%', height: 250 },
  title: {
    fontSize: 22,
    fontWeight: '700',
    color: '#2F0079',
    marginVertical: 10,
    alignSelf: 'flex-start',
  },
  dotsContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginVertical: 20,
  },
  dot: {
    width: 20,
    height: 20,
    borderRadius: 10,
    backgroundColor: '#EAEAEA',
    marginHorizontal: 6,
  },
  buttonRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '100%',
  },
  skipBtn: {
    backgroundColor: '#EAEAEA',
    borderRadius: 25,
    paddingVertical: 10,
    paddingHorizontal: 30,
  },
  skipText: { color: '#000', fontWeight: '600' },
  nextBtn: {
    backgroundColor: '#2F0079',
    borderRadius: 25,
    paddingVertical: 10,
    paddingHorizontal: 25,
  },
  nextText: { color: '#fff', fontWeight: '600' },
  disclaimer: {
    fontSize: 12,
    color: '#444',
    marginTop: 25,
    textAlign: 'center',
    lineHeight: 18,
  },
});
