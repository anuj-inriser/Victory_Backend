import React from "react";
import { Text, StyleSheet, View, ScrollView } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons"; // for the arrow icon
import Octicons from '@expo/vector-icons/Octicons';

const TopMenuSlider = () => {
    return (
        <SafeAreaView style={styles.safeArea}>
            <ScrollView
                horizontal
                showsHorizontalScrollIndicator={false}
                contentContainerStyle={styles.scrollContainer}
            >
                {/* Home */}
                <View style={styles.tabWhite}>
                    <Text style={styles.tabTextDark}>Home</Text>
                </View>

                {/* Watchlists + Arrow (joined shape) */}
                <View style={styles.watchlistWrapper}>
                    <View style={styles.watchlistLeft}>
                        <Text style={styles.tabTextLight}>Watchlists</Text>
                    </View>
                    <View style={styles.watchlistRight}>
                        <Octicons name="triangle-right" size={15.5} color="#fff" />
                    </View>
                </View>

                {/* News */}
                <View style={styles.tabWhite}>
                    <Text style={styles.tabTextDark}>News</Text>
                </View>

                {/* Pins */}
                <View style={styles.tabWhite}>
                    <Text style={styles.tabTextDark}>Pins</Text>
                </View>

                {/* Other */}
                <View style={styles.tabWhite}>
                    <Text style={styles.tabTextDark}>Other</Text>
                </View>
            </ScrollView>
        </SafeAreaView>
    );
};

const styles = StyleSheet.create({
    safeArea: {
        backgroundColor: "#fff",
        paddingTop: 5,
    },
    scrollContainer: {
        flexDirection: "row",
        alignItems: "center",
        paddingHorizontal: 10,
        paddingVertical: 6,
    },
    tabWhite: {
        flexDirection: "row",
        alignItems: "center",
        backgroundColor: "#fff",
        borderRadius: 40,
        paddingVertical: 5,
        paddingHorizontal: 16,
        marginRight: 8,
        shadowColor: "#000",
        shadowOffset: { width: 0, height: 1 },
        shadowOpacity: 0.15,
        shadowRadius: 1.5,
        elevation: 2,
    },
    tabTextDark: {
        color: "#210f47",
        fontSize: 12,
        fontFamily: "Poppins-Medium",
        fontWeight: "500",
    },
    tabTextLight: {
        color: "#fff",
        fontSize: 12,
        fontFamily: "Poppins-Medium",
        fontWeight: "500",
    },

    // 🔹 Watchlist combined button
    watchlistWrapper: {
        flexDirection: "row",
        alignItems: "center",
        marginRight: 8,
        elevation: 2,
        shadowColor: "#000",
        shadowOffset: { width: 0, height: 1 },
        shadowOpacity: 0.15,
        shadowRadius: 1.5,
    },
    watchlistLeft: {
        backgroundColor: "#210f47",
        borderTopLeftRadius: 40,
        borderBottomLeftRadius: 40,
        paddingVertical: 5,
        paddingHorizontal: 14,
    },
    watchlistRight: {
        backgroundColor: "#210f47",
        borderTopRightRadius: 40,
        borderBottomRightRadius: 40,
        paddingHorizontal: 10,
        paddingVertical: 5,
        marginLeft: 1,
    },
});

export default TopMenuSlider;
