import React from 'react';
import {
    View,
    Text,
    ImageBackground,
    StyleSheet,
    ScrollView,
    TouchableOpacity,
    Image
} from 'react-native';
import RightArrow from "../../assets/RightArrow.jpg"
import { MaterialIcons } from '@expo/vector-icons';

// Mini card reusable component
const MiniCard = ({ number, title, onPress }) => (
    <TouchableOpacity style={styles.miniCard} onPress={onPress}>
        <View style={styles.miniCardCircle}>
            <Text style={styles.miniCardNumber}>{number}</Text>
        </View>
        <Text style={styles.miniCardTitle}>{title}</Text>
    </TouchableOpacity>
);

const LearningCard = ({
    title,
    bgImage,
    progress = 0.52,
    headline = "Understand how the stock market works, its participants, and why prices move.",
    miniCards = [],
    onMiniCardPress = () => { },
    onArrowPress = () => { },
}) => {
    return (
        <View style={styles.container}>
            <View style={styles.headerRow}>
                <Text style={styles.sectionTitle}>{title}</Text>
                <TouchableOpacity onPress={onArrowPress}>
                    <View style={{
                        width: 35,
                        height: 35,
                        borderRadius: 20,
                        backgroundColor: '#E6E0E9',
                        alignItems: 'center',
                        justifyContent: 'center',
                        right: 15
                    }}
                    >
                        <MaterialIcons name="arrow-forward" size={20} color="#000" />
                    </View>
                </TouchableOpacity>
            </View>

            <ImageBackground
                source={bgImage}
                style={styles.mainCard}
                imageStyle={{ borderRadius: 15 }}
            >
                <View style={styles.progressBarBackground}>
                    
                    <View style={[
                        styles.progressBarFill,
                        { width: `${progress * 100}%` }
                    ]} />
                    <Text style={styles.progressText}>{`${Math.round(progress * 100)}%`}</Text>
                </View>
                <View style={styles.overlay}>
                    <Text style={styles.headline}>{headline}</Text>
                </View>
            </ImageBackground>

            <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.miniScroll}>
                {miniCards.map((card, index) => (
                    <MiniCard
                        key={index}
                        number={card.number}
                        title={card.title}
                        onPress={() => onMiniCardPress(card)}
                    />
                ))}
            </ScrollView>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        padding: 20,
        // backgroundColor: '#fff',
    },
    headerRow: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: 15,
    },
    sectionTitle: {
        fontSize: 18,
        fontWeight: '700',
        color: '#2D2D2D',
    },
    arrow: {
        fontSize: 24,
        color: '#555',
    },
    mainCard: {
        height: 120,
        borderRadius: 15,
        overflow: 'hidden',
        marginBottom: 12,
        justifyContent: 'flex-end',
    },
    progressBarBackground: {
        position: 'absolute',
        top: 12,
        left: 10,
        right: 10,
        height: 7,
        borderRadius: 5,
        backgroundColor: '#eee',
        flexDirection: 'row',
        alignItems: 'center',
    },
    progressBarFill: {
        backgroundColor: '#31C283',
        height: 7,
        borderRadius: 5,
    },
    progressText: {
        position: 'absolute',
        right: 0.00001,
        // top: -14,
        backgroundColor: '#31C283',
        width: 23,
        height: 23,
        borderRadius: 14,
        color: '#fff',
        fontWeight: '500',
        fontSize: 10,
        textAlign: 'center',
        lineHeight: 22,
        overflow: 'hidden'
    },

    overlay: {
        // backgroundColor: 'rgba(0,0,0,0.3)',
        padding: 13,
        borderBottomLeftRadius: 15,
        borderBottomRightRadius: 15,
    },
    headline: {
        color: '#fff',
        fontSize: 16,
        fontWeight: '500',
    },
    miniScroll: {
        // overflow: 'visible'
    },
    miniCard: {
        backgroundColor: '#E6E0E9',
        borderRadius: 13,
        padding: 15,
        // alignItems: 'flex-start',
        marginRight: 12,
        // flexDirection: 'row',
        // justifyContent: 'flex-start',
        width: 140,
        // elevation: 6, 
        
    },

    miniCardCircle: {
        width: 24,
        height: 24,
        borderRadius: 16.5,
        backgroundColor: '#333066',
        justifyContent: 'center',
        alignItems: 'center',
        marginRight: 13,

    },
    miniCardNumber: {
        color: '#fff',
        fontWeight: '600',
        fontSize: 12,
    },
    miniCardTitle: {
        color: '#2D2D2D',
        fontWeight: '500',
        fontSize: 13,
        letterSpacing: 0.7,
        flexShrink: 1,
        width: 130,
        height: 36,
        // lineHeight: 18,
    },
});

export default LearningCard;