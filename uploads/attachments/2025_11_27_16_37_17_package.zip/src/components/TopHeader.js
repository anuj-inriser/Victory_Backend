import React from "react";
import {
  View,
  TextInput,
  StyleSheet,
  Image,
  TouchableOpacity,
  StatusBar,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";

const TopHeader = () => {
  return (
    <View style={styles.container}>
      {/* 📱 Status Bar color fix */}
      <StatusBar backgroundColor="#f2edf9" barStyle="dark-content" />

      <View style={styles.header}>
        {/* 👤 Avatar */}
        <Image
          source={{
            uri: "https://randomuser.me/api/portraits/men/10.jpg",
          }}
          style={styles.avatar}
        />

        {/* 🔍 Search Bar */}
        <View style={styles.searchContainer}>
          <Ionicons name="search" size={16} color="#888" style={styles.searchIcon} />
          <TextInput
            placeholder="Search"
            placeholderTextColor="#888"
            style={styles.searchInput}
          />
        </View>

        {/* 🔔 Notification Button */}
        <TouchableOpacity style={styles.circleButton}>
          <Ionicons name="notifications-outline" size={20} color="#fff" />
          <View style={styles.badge} />
        </TouchableOpacity>

        {/* ☰ Menu Button */}
        <TouchableOpacity style={styles.circleButton}>
          <Ionicons name="menu" size={20} color="#fff" />
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: "#f2edf9", // ✅ for both header and status bar background
  },
  header: {
    backgroundColor: "#f2edf9",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 14,
    paddingTop: 8,
    paddingBottom: 10,
  },
  avatar: {
    width: 32,
    height: 32,
    borderRadius: 16,
  },
  searchContainer: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#fff",
    borderRadius: 30,
    marginHorizontal: 10,
    paddingHorizontal: 10,
    shadowColor: "#000",
    shadowOpacity: 0.05,
    shadowOffset: { width: 0, height: 1 },
    shadowRadius: 1,
    elevation: 1,
    height: 35,
  },
  searchIcon: {
    marginRight: 6,
  },
  searchInput: {
    flex: 1,
    fontSize: 14,
    color: "#333",
    paddingVertical: 0, // ✅ ensures vertical centering of placeholder text
  },
  circleButton: {
    backgroundColor: "#210f47", // ✅ deep purple
    width: 34,
    height: 34,
    borderRadius: 17,
    alignItems: "center",
    justifyContent: "center",
    marginLeft: 6,
    position: "relative",
  },
  badge: {
    position: "absolute",
    top: 6,
    right: 8,
    width: 8,
    height: 8,
    backgroundColor: "#ff3b30", // ✅ red notification dot
    borderRadius: 4,
  },
});

export default TopHeader;
