import React from "react";
import { View, Text, StyleSheet } from "react-native";
import { Ionicons } from "@expo/vector-icons";

const OrderInputBox = ({ label = "Price", value = "590.45" }) => {
    return (
        <View style={styles.container}>
            {/* Left Side: Label */}
            <View style={styles.labelBox}>
                <Text style={styles.labelText}>{label}</Text>
            </View>

            {/* Right Side: Value */}
            <View style={styles.valueBox}>
                <Text style={styles.valueText}>{value}</Text>
                <Ionicons name="checkmark" size={16} color="#210f47" style={styles.icon} />
            </View>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",
        marginHorizontal: 20,
        marginVertical: 5,
    },

    // 🟣 Left box (Price)
    labelBox: {
        backgroundColor: "#f2ebf7", // light lavender
        paddingVertical: 10,
        paddingHorizontal: 20,
        borderTopLeftRadius: 14,
        borderRadius: 14,
        width: 150,
        marginRight: 10,
    },
    labelText: {
        color: "#210f47",
        fontSize: 14,
        fontWeight: "600",
    },

    // ⚪ Right box (Value + tick)
    valueBox: {
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",
        backgroundColor: "#fff",
        paddingVertical: 10,
        paddingHorizontal: 16,
        borderRadius: 14,
        borderWidth: 1,
        borderColor: "#e0e0e0",
        width: 150,
    },
    valueText: {
        fontSize: 14,
        fontWeight: "500",
        color: "#000",
    },
    icon: {
        marginLeft: 6,
        backgroundColor: "#f2ebf7",
    },
});

export default OrderInputBox;
