import React from "react";
import {
  View,
  Text,
  Image,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";

const WatchlistItemCard = ({ data = [], ltpData = {}, onPressItem }) => {
  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      {data.map((item) => {
        const ltp = ltpData[item.symbol];
        return (
          <TouchableOpacity
            key={item.id}
            style={styles.card}
            activeOpacity={0.8}
            onPress={() => onPressItem?.(item)}
          >
            <Image source={item.logo} style={styles.logo} />
            <View style={styles.infoContainer}>
              <Text style={styles.companyName}>{item.name}</Text>
              <Text style={styles.symbol}>{item.symbol}</Text>
            </View>
            <View style={styles.rightContainer}>
              <Text style={styles.price}>
                ₹{ltp !== undefined ? ltp : "--"}
              </Text>
              <View style={styles.changeContainer}>
                <Ionicons
                  name={ltp ? "trending-up-outline" : "trending-down-outline"}
                  size={14}
                  color={ltp ? "#21C17A" : "#E53935"}
                />
                <Text
                  style={[
                    styles.changeText,
                    { color: ltp ? "#21C17A" : "#E53935" },
                  ]}
                >
                  {ltp ? "+1.38%" : "--"}
                </Text>
              </View>
            </View>
          </TouchableOpacity>
        );
      })}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: { paddingHorizontal: 10, backgroundColor: "#fff" },
  card: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#fff",
    borderRadius: 14,
    paddingVertical: 10,
    paddingHorizontal: 12,
    marginVertical: 6,
    marginHorizontal: 16,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 4,
  },
  logo: { width: 34, height: 34, resizeMode: "contain", marginRight: 10 },
  infoContainer: { flex: 1, justifyContent: "center" },
  companyName: { fontSize: 14, fontWeight: "600", color: "#333" },
  symbol: { fontSize: 12, color: "#999", marginTop: 2 },
  rightContainer: { alignItems: "flex-end" },
  price: { fontSize: 13, color: "#333", fontWeight: "600" },
  changeContainer: { flexDirection: "row", alignItems: "center", marginTop: 2 },
  changeText: { fontSize: 12, marginLeft: 4, fontWeight: "500" },
});

export default WatchlistItemCard;
