import React, { useState } from "react";
import { View, Text, StyleSheet, Platform } from "react-native";
import { Picker } from "@react-native-picker/picker";

const OrderDropdownBox = ({
    label = "",
    options = [],
    defaultValue = "",
    onChange,
}) => {
    const [selected, setSelected] = useState(defaultValue);

    const handleChange = (val) => {
        setSelected(val);
        onChange?.(val);
    };

    return (
        <View style={styles.container}>
            {/* Left Side: Label */}
            <View style={styles.labelBox}>
                <Text style={styles.labelText}>{label}</Text>
            </View>

            {/* Right Side: Dropdown */}
            <View style={styles.valueBox}>
                <Picker
                    selectedValue={selected}
                    onValueChange={handleChange}
                    mode="dropdown"
                    dropdownIconColor="#210f47"
                    style={styles.picker}
                    itemStyle={styles.pickerItem} // fix for iOS vertical align
                >
                    {options.map((opt, index) => (
                        <Picker.Item key={index} label={opt} value={opt} />
                    ))}
                </Picker>
            </View>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",
        marginHorizontal: 20,
        marginVertical: 5,
    },

    labelBox: {
        backgroundColor: "#f2ebf7",
        paddingVertical: 10,
        paddingHorizontal: 20,
        borderRadius: 14,
        width: 150,
        marginRight: 10,
    },
    labelText: {
        color: "#210f47",
        fontSize: 14,
        fontWeight: "600",
    },

    valueBox: {
        backgroundColor: "#fff",
        borderRadius: 14,
        borderWidth: 1,
        borderColor: "#e0e0e0",
        width: 150,
        height: 42, // same height
        justifyContent: "center",
    },

    // ✅ Text centered and visible
    picker: {
        width: "100%",
        height: Platform.OS === "ios" ? 42 : 50, // Android needs a bit more render space
        color: "#000",
        fontSize: 14,
        fontWeight: "500",
        paddingVertical: 0,
        marginTop: Platform.OS === "android" ? -8 : 0, // centers text on Android
    },
    pickerItem: {
        fontSize: 14,
        height: 42,
        color: "#000",
    },
});

export default OrderDropdownBox;