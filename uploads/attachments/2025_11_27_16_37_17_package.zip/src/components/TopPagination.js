import React, { useState } from "react";
import { View, Text, TouchableOpacity, StyleSheet } from "react-native";
import { Entypo } from "@expo/vector-icons";

const TopPagination = ({ style }) => {
  const [active, setActive] = useState(1);

  return (
    <View style={[styles.pagination, style]}>
      {[1, 2, 3, 4, 5].map((n) => (
        <TouchableOpacity
          key={n}
          style={[styles.pageBtn, active === n && styles.activePage]}
          onPress={() => setActive(n)}
        >
          <Text
            style={[
              styles.pageText,
              active === n ? styles.activeText : styles.inactiveText,
            ]}
          >
            {n}
          </Text>
        </TouchableOpacity>
      ))}

      {/* Three-dot icon */}
      <Entypo
        name="dots-three-vertical"
        size={14}
        color="#555"
        style={{ marginLeft: 4 }}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  pagination: {
    marginTop:5,
    marginBottom:10,
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    paddingVertical: 6,
    backgroundColor: "#fff",

    // ✅ Soft bottom shadow only
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 4 }, // 👈 Only downward
    shadowOpacity: 0.12,
    shadowRadius: 5,
    elevation: 5,

    // ✅ Remove all possible borders / outlines
    borderTopWidth: 0,
    borderTopColor:"#transparent",
    borderWidth: 0,
    borderColor: "transparent",

    zIndex: 2,
  },

  pageBtn: {
    width: 28,
    height: 28,
    borderRadius: 14,
    justifyContent: "center",
    alignItems: "center",
    marginHorizontal: 16,
  },
  activePage: {
    backgroundColor: "#ebe4f2", // soft lavender background
  },
  pageText: {
    fontSize: 13,
    fontFamily: "Poppins-Medium",
  },
  activeText: {
    color: "#000",
    fontWeight: "600",
  },
  inactiveText: {
    color: "#555",
    fontWeight: "400",
  },
});

export default TopPagination;
